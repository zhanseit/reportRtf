package com.example.rtf.controller;

import com.example.rtf.dto.user;
import com.example.rtf.service.PrintService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;
import static org.springframework.http.MediaType.APPLICATION_PDF;

@RestController
@RequestMapping("/home")
@RequiredArgsConstructor
public class RtfController {

    private final PrintService printService;

    @RequestMapping(method = RequestMethod.POST, headers = {"Accept=application/json"}, value = "/form")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity updatePerson(@RequestBody String json) {
        byte[] file = printService.printRtf(json);
        ByteArrayResource resource = new ByteArrayResource(file);
        String contenDespos = "attachment";
        String filename = "filename.rtf";
        return ResponseEntity.ok()
                .contentLength(file.length)
                .header(CONTENT_DISPOSITION, contenDespos + "; filename=" + filename)
                .body(resource);
    }
}
