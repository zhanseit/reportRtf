package com.example.rtf.service;

import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.List;

@Service
@Slf4j
public class PrintServiceImpl implements PrintService {
    @Override
    public byte[] printRtf(String json) {
        try {
            XWPFDocument document = new XWPFDocument();
            XWPFParagraph paragraph = document.createParagraph();
            XWPFRun run = paragraph.insertNewRun(0); // first paragraph, 0 is the position
            run.setText(json);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            document.write(baos);
            return baos.toByteArray();
        } catch (Exception e){
            log.error("not working printing ", e);
        }
        return new byte[0];
    }
}
