package com.example.rtf.service;

public interface PrintService {
    public byte[] printRtf(String json);
}
