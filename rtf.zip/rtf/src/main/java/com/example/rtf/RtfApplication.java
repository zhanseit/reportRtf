package com.example.rtf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RtfApplication {

	public static void main(String[] args) {
		SpringApplication.run(RtfApplication.class, args);
	}

}
